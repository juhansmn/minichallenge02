//
//  Usuario.swift
//  minichallenge02
//
//  Created by Beatriz da Silva on 16/04/20.
//  Copyright © 2020 Juan Suman. All rights reserved.
//

import Foundation

class Usuario {
    var name: String = ""
    //var avatar:
}

